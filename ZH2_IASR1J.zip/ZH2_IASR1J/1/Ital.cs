﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1
{
    public class Ital
    {
        public int ItalID { get; set; }
        public string Nev { get; set; } = string.Empty;
        public int Alkoholtartalom { get; set; }
        public int EgysegAr { get; set; }
        public bool Nepszeru { get; set; }
    }
}
