﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1
{
    internal class Sor
    {
        public int Alap { get; set; }
        public int Kitevo { get; set; }
        public int Eredmeny { get; set; }
    }
}
